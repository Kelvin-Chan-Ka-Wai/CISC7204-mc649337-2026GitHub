"""CISC7204 Assignment 02 - Module 05 Final Lab02: Creating Dashboard using Plotly and Dash.

Dashboard with two reports (1980-2013):
  * Yearly Automobile Sales Statistics
  * Recession Period Statistics
Each report shows four charts; a radio item selects the report and a dropdown selects the year.
Run:  python app.py   ->  http://127.0.0.1:8054
"""
import os

import dash
import pandas as pd
import plotly.express as px
from dash import Input, Output, dcc, html

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data", "automobile-sales.csv")

df = pd.read_csv(DATA)
df = df[(df["Year"] >= 1980) & (df["Year"] <= 2013)]
years = sorted(df["Year"].unique())
recession_df = df[df["Recession"] == 1]

REPORT_YEARLY = "Yearly Automobile Sales Statistics"
REPORT_RECESSION = "Recession Period Statistics"

app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("Automobile Sales Statistics Dashboard",
            style={"textAlign": "center", "color": "#503D36", "font-size": 40}),
    html.P("Yearly automobile sales statistics and recession period statistics (1980 - 2013).",
           style={"textAlign": "center", "color": "#F57241"}),
    html.Div([
        html.Div([
            html.Label("Select Statistics:", style={"font-weight": "bold"}),
            dcc.RadioItems(id="report-type",
                           options=[{"label": REPORT_YEARLY, "value": REPORT_YEARLY},
                                    {"label": REPORT_RECESSION, "value": REPORT_RECESSION}],
                           value=REPORT_YEARLY, inline=True, labelStyle={"margin-right": "18px"}),
        ], style={"width": "60%", "display": "inline-block", "padding": "10px 20px"}),
        html.Div([
            html.Label("Select Year:", style={"font-weight": "bold"}),
            dcc.Dropdown(id="year-dropdown",
                         options=[{"label": str(y), "value": y} for y in years],
                         value=years[0], clearable=False),
        ], style={"width": "22%", "display": "inline-block", "padding": "10px 20px"}),
    ]),
    html.Div([
        html.Div([dcc.Graph(id="chart-1")], style={"width": "49%", "display": "inline-block"}),
        html.Div([dcc.Graph(id="chart-2")], style={"width": "49%", "display": "inline-block"}),
    ]),
    html.Div([
        html.Div([dcc.Graph(id="chart-3")], style={"width": "49%", "display": "inline-block"}),
        html.Div([dcc.Graph(id="chart-4")], style={"width": "49%", "display": "inline-block"}),
    ]),
])


@app.callback(
    [Output("chart-1", "figure"), Output("chart-2", "figure"),
     Output("chart-3", "figure"), Output("chart-4", "figure")],
    [Input("report-type", "value"), Input("year-dropdown", "value")],
)
def update_dashboard(report, year):
    year = int(year)

    if report == REPORT_YEARLY:
        # 1 - average automobile sales per year for the whole period
        yearly = df.groupby("Year", as_index=False)["Automobile_Sales"].mean().round(2)
        fig1 = px.line(yearly, x="Year", y="Automobile_Sales", markers=True,
                       title="Average Automobile Sales per Year (1980 - 2013)")
        fig1.update_layout(xaxis_title="Year",
                           yaxis_title="Average Automobile Sales")

        # 2 - total monthly automobile sales for the selected year
        monthly = (df[df["Year"] == year].groupby("Month", as_index=False)["Automobile_Sales"]
                     .sum().round(2))
        fig2 = px.line(monthly, x="Month", y="Automobile_Sales", markers=True,
                       title="Total Monthly Automobile Sales in %d" % year)
        fig2.update_layout(xaxis_title="Month", yaxis_title="Total Automobile Sales")

        # 3 - average vehicles sold by vehicle type in the selected year
        by_type = (df[df["Year"] == year].groupby("Vehicle_Type", as_index=False)
                     ["Automobile_Sales"].mean().round(2))
        fig3 = px.bar(by_type, x="Vehicle_Type", y="Automobile_Sales",
                      title="Average Vehicles Sold by Vehicle Type in %d" % year,
                      color="Vehicle_Type")
        fig3.update_layout(xaxis_title="Vehicle Type",
                           yaxis_title="Average Automobile Sales")

        # 4 - total advertising expenditure by vehicle type in the selected year
        ad = (df[df["Year"] == year].groupby("Vehicle_Type", as_index=False)
                ["Advertising_Expenditure"].sum().round(2))
        fig4 = px.pie(ad, values="Advertising_Expenditure", names="Vehicle_Type",
                      title="Total Advertising Expenditure by Vehicle Type in %d" % year)
        return fig1, fig2, fig3, fig4

    # ---------------- recession report ----------------
    # 1 - average automobile sales per year during recessions
    rec_yearly = (recession_df.groupby("Year", as_index=False)["Automobile_Sales"]
                    .mean().round(2))
    fig1 = px.line(rec_yearly, x="Year", y="Automobile_Sales", markers=True,
                   title="Average Automobile Sales Fluctuation over Recession Periods")
    fig1.update_layout(xaxis_title="Year", yaxis_title="Average Automobile Sales")

    # 2 - average number of vehicles sold by vehicle type during recessions
    rec_type = (recession_df.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"]
                  .mean().round(2))
    fig2 = px.bar(rec_type, x="Vehicle_Type", y="Automobile_Sales",
                  title="Average Number of Vehicles Sold by Vehicle Type during Recessions",
                  color="Vehicle_Type")
    fig2.update_layout(xaxis_title="Vehicle Type", yaxis_title="Average Automobile Sales")

    # 3 - advertising expenditure share by vehicle type during recessions
    rec_ad = (recession_df.groupby("Vehicle_Type", as_index=False)["Advertising_Expenditure"]
                .sum().round(2))
    fig3 = px.pie(rec_ad, values="Advertising_Expenditure", names="Vehicle_Type",
                  title="Total Expenditure Share by Vehicle Type during Recessions")

    # 4 - effect of the unemployment rate on sales by vehicle type during recessions
    rec_unemp = (recession_df.assign(Unemployment_Rate=recession_df["unemployment_rate"].round(1))
                   .groupby(["Unemployment_Rate", "Vehicle_Type"], as_index=False)
                   ["Automobile_Sales"].mean().round(2))
    fig4 = px.bar(rec_unemp, x="Unemployment_Rate", y="Automobile_Sales",
                  color="Vehicle_Type", barmode="group",
                  title="Effect of Unemployment Rate on Vehicle Type and Sales")
    fig4.update_layout(xaxis_title="Unemployment Rate (%)",
                       yaxis_title="Average Automobile Sales")
    return fig1, fig2, fig3, fig4


if __name__ == "__main__":
    app.run(debug=True, port=8054)
