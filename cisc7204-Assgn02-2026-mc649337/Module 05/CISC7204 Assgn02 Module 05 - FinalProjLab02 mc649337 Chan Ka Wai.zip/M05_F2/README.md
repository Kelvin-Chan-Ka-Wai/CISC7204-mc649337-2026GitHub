# Module 05 Final Lab02 - Creating Dashboard using Plotly and Dash

CISC7204 Assignment 02 - Dash project space.

## Files
- `app.py` - the Dash application (the file that was developed in the lab)
- `data/automobile-sales.csv` - dataset used by the application
- `requirements.txt` - Python packages needed to run it

## Run

```bash
python -m pip install -r requirements.txt
python app.py  ->  http://127.0.0.1:8054
```

Then open the printed URL in a browser. The screenshot of the running dashboard is part of the
submission (`Screen Shots/` of the module).
