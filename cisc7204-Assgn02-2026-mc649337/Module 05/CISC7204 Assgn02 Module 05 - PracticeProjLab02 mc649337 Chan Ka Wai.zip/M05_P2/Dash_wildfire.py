"""CISC7204 Assignment 02 - Module 05 Practice Lab02: Creating Dashboards.

Dashboard: select a Region (radio items) and a Year (dropdown) to see
 - a pie chart of the average estimated fire area per region for that year
 - a bar chart of the average number of fire pixels per region for that year
Run:  python app.py   ->  http://127.0.0.1:8053
"""
import os

import dash
import pandas as pd
import plotly.express as px
from dash import Input, Output, dcc, html

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data", "Historical_Wildfires.csv")

df = pd.read_csv(DATA)
df["Year"] = pd.to_datetime(df["Date"], errors="coerce").dt.year
df = df.dropna(subset=["Year"])
df["Year"] = df["Year"].astype(int)

regions = sorted(df["Region"].dropna().unique())
years = sorted(df["Year"].unique())

app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("Australia Wildfire Dashboard",
            style={"textAlign": "center", "color": "#503D36", "font-size": 40}),
    html.P("Average estimated fire area and average count of fire pixels per region for a selected year.",
           style={"textAlign": "center", "color": "#F57241"}),
    html.Div([
        html.Div([
            html.Label("Select Region:", style={"font-weight": "bold"}),
            dcc.RadioItems(id="region-radio",
                           options=[{"label": r, "value": r} for r in regions],
                           value=regions[0], inline=True, labelStyle={"margin-right": "12px"}),
        ], style={"width": "70%", "display": "inline-block", "padding": "10px 20px"}),
        html.Div([
            html.Label("Select Year:", style={"font-weight": "bold"}),
            dcc.Dropdown(id="year-dropdown",
                         options=[{"label": str(y), "value": y} for y in years],
                         value=years[-1], clearable=False),
        ], style={"width": "25%", "display": "inline-block", "padding": "10px 20px"}),
    ]),
    html.Div([
        html.Div([dcc.Graph(id="pie-chart")], style={"width": "49%", "display": "inline-block"}),
        html.Div([dcc.Graph(id="bar-chart")], style={"width": "49%", "display": "inline-block"}),
    ]),
])


@app.callback(
    [Output("pie-chart", "figure"), Output("bar-chart", "figure")],
    [Input("region-radio", "value"), Input("year-dropdown", "value")],
)
def update_charts(region, year):
    year_df = df[df["Year"] == int(year)]
    area = (year_df.groupby("Region", as_index=False)["Estimated_fire_area"].mean()
                   .round(2))
    pie = px.pie(area, values="Estimated_fire_area", names="Region",
                 title="Average Estimated Fire Area in %s (%s)" % (region, year))
    counts = (year_df.groupby("Region", as_index=False)["Count"].mean().round(2))
    bar = px.bar(counts, x="Region", y="Count",
                 title="Average Count of Pixels for Presumed Vegetation Fires in %s" % year,
                 color="Region")
    bar.update_layout(xaxis_title="Region", yaxis_title="Average Count of Pixels")
    return pie, bar


if __name__ == "__main__":
    app.run(debug=True, port=8053)
